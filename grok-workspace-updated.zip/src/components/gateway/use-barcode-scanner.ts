import { useEffect, useRef, useState } from "react";

export type CameraStatus = "starting" | "live" | "denied" | "missing" | "error";

type TorchCapabilities = MediaTrackCapabilities & { torch?: boolean };

export function useBarcodeScanner(onCode: (code: string) => void, generation: number) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const onCodeRef = useRef(onCode);
  onCodeRef.current = onCode;
  const streamRef = useRef<MediaStream | null>(null);
  const [status, setStatus] = useState<CameraStatus>("starting");
  const [torchOn, setTorchOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) {
      setStatus("error");
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setStatus("missing");
      return;
    }

    let stopped = false;
    let controls: { stop: () => void } | null = null;
    setStatus("starting");
    setTorchOn(false);
    setTorchSupported(false);

    const start = async () => {
      try {
        const { BrowserMultiFormatReader } = await import("@zxing/browser");
        if (stopped) return;
        const reader = new BrowserMultiFormatReader(undefined, {
          delayBetweenScanAttempts: 280,
        });
        const nextControls = await reader.decodeFromConstraints(
          { video: { facingMode: { ideal: "environment" } }, audio: false },
          video,
          (result) => {
            if (!result) return;
            try {
              onCodeRef.current(result.getText());
            } catch {
              /* keep the camera loop alive */
            }
          },
        );
        if (stopped) {
          nextControls.stop();
          return;
        }
        controls = nextControls;
        const stream = video.srcObject instanceof MediaStream ? video.srcObject : null;
        streamRef.current = stream;
        const track = stream?.getVideoTracks()[0];
        const caps = track?.getCapabilities?.() as TorchCapabilities | undefined;
        setTorchSupported(Boolean(caps?.torch));
        setStatus("live");
      } catch (error) {
        if (stopped) return;
        const name = error instanceof DOMException ? error.name : "";
        if (name === "NotAllowedError" || name === "SecurityError") setStatus("denied");
        else if (name === "NotFoundError" || name === "OverconstrainedError") setStatus("missing");
        else setStatus("error");
      }
    };

    void start();

    return () => {
      stopped = true;
      controls?.stop();
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      if (video.srcObject instanceof MediaStream) {
        video.srcObject.getTracks().forEach((track) => track.stop());
        video.srcObject = null;
      }
    };
  }, [generation]);

  async function toggleTorch(): Promise<boolean> {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return false;
    const next = !torchOn;
    try {
      await track.applyConstraints({
        advanced: [{ torch: next }],
      } as MediaTrackConstraints);
      setTorchOn(next);
      return true;
    } catch {
      setTorchSupported(false);
      setTorchOn(false);
      return false;
    }
  }

  return { videoRef, status, torchOn, torchSupported, toggleTorch };
}
