import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Copy,
  ExternalLink,
  Flashlight,
  History,
  Keyboard,
  ScanLine,
  Share2,
  Trash2,
  X,
} from "lucide-react";
import { toast, Toaster } from "sonner";
import {
  CARRIERS,
  SAMPLE_CODES,
  carrierById,
  confidenceLabel,
  detectCarrier,
  type CarrierId,
} from "@/lib/carriers";
import { formatWhen, loadHistory, saveHistory, type Scan } from "@/lib/scans";
import { cn } from "@/lib/utils";
import { useBarcodeScanner } from "@/components/gateway/use-barcode-scanner";

type Panel = "scan" | "history" | "manual";

export function ScannerApp() {
  const [history, setHistory] = useState<Scan[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [activeCode, setActiveCode] = useState<string | null>(null);
  const [panel, setPanel] = useState<Panel>("scan");
  const [generation, setGeneration] = useState(0);
  const panelRef = useRef(panel);
  panelRef.current = panel;
  const commitRef = useRef<(raw: string, source: Scan["source"]) => void>(() => {});
  const lastCamera = useRef({ code: "", at: 0 });

  useEffect(() => {
    setHistory(loadHistory());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveHistory(history);
  }, [history, hydrated]);

  const commit = (raw: string, source: Scan["source"]) => {
    const detection = detectCarrier(raw);
    if (detection.code.length < 4) {
      if (source === "manual") toast.error("Nummer zu kurz");
      return;
    }
    const best = detection.matches[0];
    const now = Date.now();
    setHistory((prev) => {
      const existing = prev.find((item) => item.code === detection.code);
      const next: Scan = existing
        ? {
            ...existing,
            at: now,
            source,
            confidence: best.score,
            reason: best.reason,
            detectedCarrierId: best.carrierId,
            carrierId: existing.corrected ? existing.carrierId : best.carrierId,
          }
        : {
            id: crypto.randomUUID(),
            code: detection.code,
            carrierId: best.carrierId,
            detectedCarrierId: best.carrierId,
            confidence: best.score,
            reason: best.reason,
            at: now,
            source,
            corrected: false,
          };
      return [next, ...prev.filter((item) => item.code !== detection.code)].slice(0, 100);
    });
    setActiveCode(detection.code);
    setPanel("scan");
  };
  commitRef.current = commit;

  const scanner = useBarcodeScanner((text) => {
    if (panelRef.current !== "scan") return;
    const detected = detectCarrier(text);
    const now = Date.now();
    if (detected.code === lastCamera.current.code && now - lastCamera.current.at < 4000) return;
    lastCamera.current = { code: detected.code, at: now };
    commitRef.current(text, "camera");
  }, generation);

  const active = history.find((item) => item.code === activeCode) ?? null;

  async function copyText(value: string, message: string) {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(message);
    } catch {
      toast.error("Kopieren nicht möglich");
    }
  }

  async function shareScan(scan: Scan) {
    const carrier = carrierById(scan.carrierId);
    const url = carrier.trackingUrl(scan.code);
    const text = `${carrier.name} ${scan.code}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: carrier.name, text, url });
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return;
      }
    }
    await copyText(`${text}\n${url}`, "Link kopiert");
  }

  function setCarrier(code: string, carrierId: CarrierId) {
    setHistory((prev) =>
      prev.map((item) =>
        item.code === code
          ? { ...item, carrierId, corrected: carrierId !== item.detectedCarrierId }
          : item,
      ),
    );
  }

  function remove(code: string) {
    setHistory((prev) => prev.filter((item) => item.code !== code));
    setActiveCode((current) => (current === code ? null : current));
  }

  async function onTorch() {
    if (scanner.status !== "live") {
      toast.error("Kamera ist nicht aktiv");
      return;
    }
    if (!scanner.torchSupported && !scanner.torchOn) {
      toast.error("Taschenlampe an diesem Gerät nicht verfügbar");
      return;
    }
    const ok = await scanner.toggleTorch();
    if (!ok) toast.error("Taschenlampe an diesem Gerät nicht verfügbar");
  }

  const cameraMessage =
    scanner.status === "starting"
      ? "Kamera wird gestartet…"
      : scanner.status === "denied"
        ? "Kein Kamerazugriff. Erlaube die Kamera oder gib die Nummer ein."
        : scanner.status === "missing"
          ? "Keine Kamera gefunden. Die Nummer kannst du eintippen."
          : scanner.status === "error"
            ? "Kamera konnte nicht gestartet werden."
            : null;

  return (
    <div className="min-h-dvh bg-bg text-fg lg:grid lg:grid-cols-3">
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          style: {
            background: "var(--color-surface)",
            color: "var(--color-fg)",
            border: "1px solid var(--color-line)",
          },
        }}
      />
      <section className="relative h-dvh overflow-hidden lg:col-span-2">
        <div className="stage-grid absolute inset-0" aria-hidden="true" />
        <video
          ref={scanner.videoRef}
          className={cn(
            "absolute inset-0 h-full w-full object-cover",
            scanner.status !== "live" && "opacity-0",
          )}
          muted
          autoPlay
          playsInline
        />
        <div className="relative flex h-full min-h-0 flex-col">
          <header className="flex items-center gap-3 bg-bg px-4 py-3">
            <div className="flex size-12 items-center justify-center rounded-2xl border border-line bg-surface text-primary">
              <ScanLine className="size-6" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-lg font-semibold leading-tight">Multi-Carrier Gateway</h1>
              <p className="text-sm text-muted">Scan · Erkennen · Tracking</p>
            </div>
            <IconButton
              label={scanner.torchOn ? "Taschenlampe aus" : "Taschenlampe an"}
              pressed={scanner.torchOn}
              onClick={() => void onTorch()}
            >
              <Flashlight className="size-5" />
            </IconButton>
            <IconButton label="Nummer eingeben" onClick={() => setPanel("manual")}>
              <Keyboard className="size-5" />
            </IconButton>
            <IconButton
              label="Verlauf"
              className="lg:hidden"
              onClick={() => setPanel("history")}
            >
              <History className="size-5" />
            </IconButton>
          </header>

          <div className="flex min-h-0 flex-1 flex-col items-center justify-center px-6">
            <Viewfinder live={scanner.status === "live"} />
            <p className="mt-6 max-w-sm text-center text-sm text-muted" role="status">
              {cameraMessage ?? "Halte den Barcode in den Rahmen. Die Kamera bleibt offen."}
            </p>
            {scanner.status !== "live" && scanner.status !== "starting" ? (
              <div className="mt-4 flex gap-2">
                <button
                  type="button"
                  className="h-12 rounded-full border border-line bg-surface px-4 text-sm font-medium"
                  onClick={() => setGeneration((value) => value + 1)}
                >
                  Erneut versuchen
                </button>
                <button
                  type="button"
                  className="h-12 rounded-full bg-primary px-4 text-sm font-semibold text-primary-ink"
                  onClick={() => setPanel("manual")}
                >
                  Nummer eingeben
                </button>
              </div>
            ) : null}
          </div>

          <div className="safe-bottom bg-bg px-4 pt-2">
            {active ? (
              <ResultCard
                scan={active}
                onCarrier={(carrierId) => setCarrier(active.code, carrierId)}
                onClose={() => setActiveCode(null)}
                onCopy={() => void copyText(active.code, "Nummer kopiert")}
                onShare={() => void shareScan(active)}
              />
            ) : (
              <p className="pb-4 text-center text-sm text-muted">
                {history[0]
                  ? `Zuletzt ${carrierById(history[0].carrierId).short} · ${history[0].code}`
                  : "Noch keine Sendung in dieser Sitzung."}
              </p>
            )}
          </div>
        </div>
        <p className="sr-only" aria-live="polite">
          {active ? `${active.code}, ${carrierById(active.carrierId).name}` : ""}
        </p>
      </section>

      <aside className="hidden h-dvh overflow-y-auto border-l border-line bg-surface lg:block">
        <HistoryPanel
          history={history}
          activeCode={activeCode}
          onSelect={(code) => {
            setActiveCode(code);
            setPanel("scan");
          }}
          onRemove={remove}
          onClear={() => {
            setHistory([]);
            setActiveCode(null);
          }}
        />
      </aside>

      {panel === "history" ? (
        <div className="fixed inset-0 z-30 flex flex-col bg-bg lg:hidden">
          <HistoryPanel
            history={history}
            activeCode={activeCode}
            onClose={() => setPanel("scan")}
            onSelect={(code) => {
              setActiveCode(code);
              setPanel("scan");
            }}
            onRemove={remove}
            onClear={() => {
              setHistory([]);
              setActiveCode(null);
            }}
          />
        </div>
      ) : null}

      {panel === "manual" ? (
        <ManualDialog
          onClose={() => setPanel("scan")}
          onSubmit={(value) => commit(value, "manual")}
        />
      ) : null}
    </div>
  );
}

function IconButton({
  label,
  pressed,
  className,
  onClick,
  children,
}: {
  label: string;
  pressed?: boolean;
  className?: string;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "inline-flex size-12 shrink-0 items-center justify-center rounded-full border border-line bg-surface text-fg transition-colors duration-200 hover:bg-surface-2",
        pressed && "border-primary bg-primary text-primary-ink",
        className,
      )}
    >
      {children}
    </button>
  );
}

function Viewfinder({ live }: { live: boolean }) {
  const corner = "absolute size-8 border-primary";
  return (
    <div className="relative size-64" aria-hidden="true">
      <span className={cn(corner, "top-0 left-0 border-t-4 border-l-4")} />
      <span className={cn(corner, "top-0 right-0 border-t-4 border-r-4")} />
      <span className={cn(corner, "bottom-0 left-0 border-b-4 border-l-4")} />
      <span className={cn(corner, "right-0 bottom-0 border-r-4 border-b-4")} />
      {live ? <span className="mcg-sweep absolute top-1/2 right-6 left-6 h-0.5 bg-primary" /> : null}
    </div>
  );
}

function ResultCard({
  scan,
  onCarrier,
  onClose,
  onCopy,
  onShare,
}: {
  scan: Scan;
  onCarrier: (carrierId: CarrierId) => void;
  onClose: () => void;
  onCopy: () => void;
  onShare: () => void;
}) {
  const carrier = carrierById(scan.carrierId);
  const detected = carrierById(scan.detectedCarrierId);
  return (
    <article className="result-card mb-4 rounded-3xl border border-line bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-primary uppercase">
            {confidenceLabel(scan.confidence)}
          </p>
          <h2 className="mt-1 text-xl font-semibold">{carrier.name}</h2>
        </div>
        <button
          type="button"
          aria-label="Ergebnis einklappen"
          onClick={onClose}
          className="inline-flex size-12 items-center justify-center rounded-full border border-line text-fg"
        >
          <X className="size-5" />
        </button>
      </div>
      <p className="mt-3 font-mono text-lg break-all">{scan.code}</p>
      <p className="mt-1 text-sm text-muted">
        {scan.corrected ? `Manuell gewählt · erkannt als ${detected.name}. ` : ""}
        {scan.reason}
      </p>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {CARRIERS.map((item) => {
          const selected = item.id === scan.carrierId;
          return (
            <button
              key={item.id}
              type="button"
              aria-pressed={selected}
              onClick={() => onCarrier(item.id)}
              className={cn(
                "h-12 shrink-0 rounded-full border px-3 text-sm font-medium",
                selected
                  ? "border-primary bg-primary text-primary-ink"
                  : "border-line bg-surface-2 text-fg",
              )}
            >
              {item.short}
            </button>
          );
        })}
      </div>
      <div className="mt-4 flex flex-col gap-2">
        <a
          href={carrier.trackingUrl(scan.code)}
          target="_blank"
          rel="noreferrer"
          className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-primary font-semibold text-primary-ink"
        >
          <ExternalLink className="size-5" aria-hidden="true" />
          Tracking öffnen
        </a>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onCopy}
            className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-line bg-surface-2 text-sm font-medium"
          >
            <Copy className="size-5" aria-hidden="true" />
            Kopieren
          </button>
          <button
            type="button"
            onClick={onShare}
            className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-line bg-surface-2 text-sm font-medium"
          >
            <Share2 className="size-5" aria-hidden="true" />
            Teilen
          </button>
        </div>
      </div>
    </article>
  );
}

function HistoryPanel({
  history,
  activeCode,
  onSelect,
  onRemove,
  onClear,
  onClose,
}: {
  history: Scan[];
  activeCode: string | null;
  onSelect: (code: string) => void;
  onRemove: (code: string) => void;
  onClear: () => void;
  onClose?: () => void;
}) {
  const [confirm, setConfirm] = useState(false);
  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center gap-3 border-b border-line px-4 py-3">
        {onClose ? (
          <button
            type="button"
            aria-label="Zurück zum Scan"
            onClick={onClose}
            className="inline-flex size-12 items-center justify-center rounded-full border border-line"
          >
            <X className="size-5" />
          </button>
        ) : null}
        <div className="min-w-0 flex-1">
          <h2 className="text-lg font-semibold">Verlauf</h2>
          <p className="text-sm text-muted">Nur auf diesem Gerät</p>
        </div>
        {history.length > 0 && !confirm ? (
          <button
            type="button"
            onClick={() => setConfirm(true)}
            className="h-12 rounded-full px-3 text-sm text-muted"
          >
            Alle löschen
          </button>
        ) : null}
        {confirm ? (
          <button
            type="button"
            onClick={() => {
              onClear();
              setConfirm(false);
            }}
            className="h-12 rounded-full bg-primary px-3 text-sm font-semibold text-primary-ink"
          >
            Wirklich löschen
          </button>
        ) : null}
      </div>
      {history.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
          <ScanLine className="size-8 text-muted" aria-hidden="true" />
          <p className="mt-3 text-sm text-muted">
            Noch keine Sendungen. Scanne einen Code oder gib eine Nummer ein.
          </p>
        </div>
      ) : (
        <ul className="min-h-0 flex-1 overflow-y-auto">
          {history.map((scan) => {
            const carrier = carrierById(scan.carrierId);
            const selected = scan.code === activeCode;
            return (
              <li key={scan.id} className="border-b border-line">
                <div className={cn("flex items-center gap-2 px-3 py-2", selected && "bg-surface-2")}>
                  <button type="button" onClick={() => onSelect(scan.code)} className="min-w-0 flex-1 py-2 text-left">
                    <span className="block text-sm font-semibold">{carrier.name}</span>
                    <span className="mt-1 block truncate font-mono text-sm">{scan.code}</span>
                    <span className="mt-1 block text-xs text-muted">{formatWhen(scan.at)}</span>
                  </button>
                  <a
                    href={carrier.trackingUrl(scan.code)}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={`Tracking für ${scan.code} öffnen`}
                    className="inline-flex size-12 items-center justify-center rounded-full border border-line"
                  >
                    <ExternalLink className="size-5" />
                  </a>
                  <button
                    type="button"
                    aria-label={`${scan.code} löschen`}
                    onClick={() => onRemove(scan.code)}
                    className="inline-flex size-12 items-center justify-center rounded-full border border-line"
                  >
                    <Trash2 className="size-5" />
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function ManualDialog({
  onClose,
  onSubmit,
}: {
  onClose: () => void;
  onSubmit: (value: string) => void;
}) {
  const [draft, setDraft] = useState("");
  const detection = draft.trim().length >= 4 ? detectCarrier(draft) : null;
  const best = detection?.matches[0];

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-bg/80 p-4 lg:items-center">
      <form
        className="safe-bottom w-full max-w-md rounded-3xl border border-line bg-surface p-4"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit(draft);
        }}
      >
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-semibold">Nummer eingeben</h2>
          <button
            type="button"
            aria-label="Schließen"
            onClick={onClose}
            className="inline-flex size-12 items-center justify-center rounded-full border border-line"
          >
            <X className="size-5" />
          </button>
        </div>
        <label className="mt-4 block text-sm text-muted" htmlFor="tracking-code">
          Sendungsnummer
        </label>
        <input
          id="tracking-code"
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          autoFocus
          autoCapitalize="characters"
          autoCorrect="off"
          spellCheck={false}
          placeholder="z. B. 00340434161234567890"
          className="mt-2 h-12 w-full rounded-2xl border border-line bg-bg px-3 font-mono text-fg placeholder:text-muted"
        />
        <p className="mt-2 text-sm text-muted">
          {best ? `${confidenceLabel(best.score)} · ${carrierById(best.carrierId).name}` : "Mindestens 4 Zeichen"}
        </p>
        <button
          type="submit"
          disabled={!detection}
          className="mt-3 inline-flex h-12 w-full items-center justify-center rounded-full bg-primary font-semibold text-primary-ink disabled:opacity-40"
        >
          Übernehmen
        </button>
        <p className="mt-5 text-sm text-muted">Testnummern, fiktiv</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {SAMPLE_CODES.map((sample) => (
            <button
              key={sample.code}
              type="button"
              onClick={() => onSubmit(sample.code)}
              className="h-12 rounded-full border border-line bg-surface-2 px-3 text-sm"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </form>
    </div>
  );
}
