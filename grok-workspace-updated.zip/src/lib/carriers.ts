export type CarrierId =
  | "deutsche_post"
  | "dhl_paket"
  | "dhl_express"
  | "dpd"
  | "gls"
  | "hermes"
  | "ups"
  | "fedex"
  | "post_at";

export interface Carrier {
  id: CarrierId;
  name: string;
  short: string;
  trackingUrl: (code: string) => string;
}

const enc = encodeURIComponent;

export const CARRIERS: Carrier[] = [
  {
    id: "deutsche_post",
    name: "Deutsche Post",
    short: "Post",
    trackingUrl: (code) =>
      `https://www.deutschepost.de/de/s/sendungsverfolgung.html?piececode=${enc(code)}`,
  },
  {
    id: "dhl_paket",
    name: "DHL Paket",
    short: "DHL",
    trackingUrl: (code) =>
      `https://www.dhl.de/de/privatkunden/pakete-empfangen/verfolgen.html?piececode=${enc(code)}`,
  },
  {
    id: "dhl_express",
    name: "DHL Express",
    short: "DHL Exp",
    trackingUrl: (code) =>
      `https://www.dhl.com/de-de/home/tracking/tracking-express.html?submit=1&tracking-id=${enc(code)}`,
  },
  {
    id: "dpd",
    name: "DPD",
    short: "DPD",
    trackingUrl: (code) => `https://tracking.dpd.de/status/de_DE/parcel/${enc(code)}`,
  },
  {
    id: "gls",
    name: "GLS",
    short: "GLS",
    trackingUrl: (code) => `https://gls-group.com/DE/de/paketverfolgung?match=${enc(code)}`,
  },
  {
    id: "hermes",
    name: "Hermes",
    short: "Hermes",
    trackingUrl: (code) =>
      `https://www.myhermes.de/empfangen/sendungsverfolgung/sendungsinformation/#${enc(code)}`,
  },
  {
    id: "ups",
    name: "UPS",
    short: "UPS",
    trackingUrl: (code) => `https://www.ups.com/track?loc=de_DE&tracknum=${enc(code)}`,
  },
  {
    id: "fedex",
    name: "FedEx",
    short: "FedEx",
    trackingUrl: (code) => `https://www.fedex.com/fedextrack/?trknbr=${enc(code)}&locale=de_DE`,
  },
  {
    id: "post_at",
    name: "Österreichische Post",
    short: "Post AT",
    trackingUrl: (code) => `https://www.post.at/s/sendungsdetails?snr=${enc(code)}`,
  },
];

export function carrierById(id: string): Carrier {
  return CARRIERS.find((carrier) => carrier.id === id) ?? CARRIERS[1];
}

export interface CarrierMatch {
  carrierId: CarrierId;
  score: number;
  reason: string;
}

export interface Detection {
  code: string;
  matches: CarrierMatch[];
}

export interface SampleCode {
  label: string;
  code: string;
}

export const SAMPLE_CODES: SampleCode[] = [
  { label: "UPS", code: "1Z999AA10123456784" },
  { label: "DHL Express", code: "1234567890" },
  { label: "DHL Paket", code: "00340434161234567890" },
  { label: "Deutsche Post", code: "RR123456789DE" },
  { label: "DPD", code: "01501234567890" },
  { label: "GLS", code: "12345678901" },
  { label: "Hermes", code: "H12345678901234" },
  { label: "FedEx", code: "96123456789012345678" },
  { label: "Post AT", code: "EE123456789AT" },
];

const QUERY_KEYS = new Set([
  "piececode",
  "tracking-id",
  "trackingid",
  "tracknum",
  "trknbr",
  "match",
  "snr",
  "idc",
  "code",
  "trackingnumber",
]);

export function confidenceLabel(score: number): string {
  if (score >= 85) return "Sicher erkannt";
  if (score >= 60) return "Wahrscheinlich";
  return "Bitte prüfen";
}

export function normalizeCode(raw: string): string {
  return raw
    .trim()
    .replace(/^\][A-Za-z]\d/, "")
    .replace(/[\s-]+/g, "")
    .toUpperCase();
}

export function extractCode(raw: string): string {
  const trimmed = raw.trim();
  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const url = new URL(trimmed);
      for (const [key, value] of url.searchParams) {
        if (QUERY_KEYS.has(key.toLowerCase()) && value.trim().length >= 4) {
          return normalizeCode(value);
        }
      }
      if (url.hash.length > 4) return normalizeCode(url.hash.slice(1));
      const last = url.pathname.split("/").filter(Boolean).pop();
      if (last && last.length >= 8 && /\d/.test(last) && !last.includes(".")) {
        return normalizeCode(last);
      }
    } catch {
      /* keep the raw text */
    }
  }
  return normalizeCode(trimmed);
}

function isCarrierId(value: string): value is CarrierId {
  return CARRIERS.some((carrier) => carrier.id === value);
}

export { isCarrierId };

/**
 * Best-effort format scoring. Overlapping numeric lengths stay correctable
 * in the UI. Keep in sync with the Android CarrierDetector.
 */
export function detectCarrier(raw: string): Detection {
  const code = extractCode(raw);
  const scores: CarrierMatch[] = [];

  const put = (carrierId: CarrierId, score: number, reason: string) => {
    const index = scores.findIndex((item) => item.carrierId === carrierId);
    if (index >= 0) {
      if (score > scores[index].score) scores[index] = { carrierId, score, reason };
      return;
    }
    scores.push({ carrierId, score, reason });
  };

  if (/^1Z[0-9A-Z]{16}$/.test(code)) put("ups", 100, "UPS-Format 1Z");
  if (/^T\d{10}$/.test(code)) put("ups", 86, "UPS-InfoNotice");

  const s10 = /^([A-Z]{2})(\d{9})([A-Z]{2})$/.exec(code);
  if (s10) {
    const prefix = s10[1];
    const country = s10[3];
    if (country === "AT") {
      put("post_at", 98, "S10 mit Länderkennzeichen AT");
    } else if (country === "DE") {
      if (/^[RCELUVA]/.test(prefix)) {
        put("deutsche_post", 94, "S10-Einschreiben Deutschland");
      } else {
        put("deutsche_post", 80, "S10 mit Länderkennzeichen DE");
      }
      put("dhl_paket", 55, "S10 mit Länderkennzeichen DE");
    } else {
      put("deutsche_post", 52, "Internationales S10");
      put("dhl_express", 48, "Internationales S10");
    }
  }

  if (/^(JJD|JVGL)/.test(code) || /^0034043\d+/.test(code)) {
    put("dhl_paket", 97, "DHL-Paketkennung");
  }
  if (/^JD\d{10,}$/.test(code)) put("dhl_express", 90, "DHL-Express-Kennung JD");
  if (/^0034\d{10,}$/.test(code)) put("dhl_paket", 92, "DHL-Präfix 0034");
  if (/^H\d{12,16}$/.test(code)) put("hermes", 90, "Hermes-Präfix H");
  if (/^DT\d{12}$/.test(code)) put("fedex", 92, "FedEx Door Tag");

  if (/^\d+$/.test(code)) {
    const length = code.length;
    if (length === 10) put("dhl_express", 88, "10-stellige Express-Waybill");
    if (length === 11) put("gls", 84, "11-stellige GLS-Nummer");
    if (length === 12) {
      if (code.startsWith("00")) put("dhl_paket", 86, "12-stellig mit DHL-Präfix");
      else {
        put("fedex", 70, "12-stellige FedEx-Nummer");
        put("dhl_paket", 62, "12-stellige DHL-Nummer");
        put("gls", 48, "12-stellige GLS-Nummer");
      }
    }
    if (length === 13) put("gls", 60, "13-stellige GLS-Nummer");
    if (length === 14) {
      if (/^(01|05|06|09)/.test(code)) put("dpd", 86, "14-stellig mit DPD-Präfix");
      else put("dpd", 72, "14-stellige DPD-Nummer");
      put("hermes", 68, "14-stellige Hermes-Nummer");
    }
    if (length === 15) put("fedex", 82, "15-stellige FedEx-Nummer");
    if (length === 16) {
      put("hermes", 74, "16-stellige Hermes-Nummer");
      put("dpd", 50, "16-stellige DPD-Nummer");
    }
    if (length === 18) put("ups", 44, "18-stellige UPS-Nummer");
    if (length >= 20 && length <= 22) {
      if (code.startsWith("0034")) put("dhl_paket", 93, "DHL-Leitcode");
      else if (code.startsWith("96")) put("fedex", 88, "FedEx-Nummer 96…");
      else {
        put("dhl_paket", 64, "Lange numerische Sendungsnummer");
        put("fedex", 58, "Lange FedEx-Nummer");
      }
    }
    if (length === 8) put("gls", 40, "8-stellige GLS-Referenz");
    if (length === 9) put("ups", 40, "9-stellige UPS-Referenz");
  }

  if (scores.length === 0) put("dhl_paket", 20, "Kein eindeutiges Format");
  scores.sort((a, b) => b.score - a.score);
  return { code, matches: scores };
}
