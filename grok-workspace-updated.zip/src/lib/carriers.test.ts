import assert from "node:assert/strict";
import { test } from "node:test";
import { detectCarrier, SAMPLE_CODES } from "./carriers.ts";

const expected: Record<string, string> = {
  UPS: "ups",
  "DHL Express": "dhl_express",
  "DHL Paket": "dhl_paket",
  "Deutsche Post": "deutsche_post",
  DPD: "dpd",
  GLS: "gls",
  Hermes: "hermes",
  FedEx: "fedex",
  "Post AT": "post_at",
};

test("sample codes detect the labeled carrier", () => {
  for (const sample of SAMPLE_CODES) {
    const detection = detectCarrier(sample.code);
    assert.equal(detection.matches[0]?.carrierId, expected[sample.label], sample.label);
    assert.ok(detection.matches[0].score >= 80, sample.label);
  }
});

test("tracking links and lowercase input still resolve", () => {
  const fromUrl = detectCarrier(
    "https://tracking.dpd.de/status/de_DE/parcel/01501234567890",
  );
  assert.equal(fromUrl.code, "01501234567890");
  assert.equal(fromUrl.matches[0]?.carrierId, "dpd");

  const lower = detectCarrier("1z999aa10123456784");
  assert.equal(lower.matches[0]?.carrierId, "ups");
});
