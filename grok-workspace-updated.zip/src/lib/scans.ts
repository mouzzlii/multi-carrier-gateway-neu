import { CARRIERS, type CarrierId } from "@/lib/carriers";

export interface Scan {
  id: string;
  code: string;
  carrierId: CarrierId;
  detectedCarrierId: CarrierId;
  confidence: number;
  reason: string;
  at: number;
  source: "camera" | "manual";
  corrected: boolean;
}

const STORAGE_KEY = "mcg.history.v1";

function isCarrierId(value: unknown): value is CarrierId {
  return typeof value === "string" && CARRIERS.some((carrier) => carrier.id === value);
}

export function loadHistory(): Scan[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap((item) => {
      if (!item || typeof item !== "object") return [];
      const row = item as Partial<Scan>;
      if (typeof row.id !== "string" || typeof row.code !== "string") return [];
      if (!isCarrierId(row.carrierId) || !isCarrierId(row.detectedCarrierId)) return [];
      if (typeof row.at !== "number" || typeof row.confidence !== "number") return [];
      return [
        {
          id: row.id,
          code: row.code,
          carrierId: row.carrierId,
          detectedCarrierId: row.detectedCarrierId,
          confidence: row.confidence,
          reason: typeof row.reason === "string" ? row.reason : "",
          at: row.at,
          source: row.source === "manual" ? "manual" : "camera",
          corrected: Boolean(row.corrected),
        },
      ];
    });
  } catch {
    return [];
  }
}

export function saveHistory(items: Scan[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, 100)));
}

export function formatWhen(at: number, now = Date.now()): string {
  const seconds = Math.max(0, Math.round((now - at) / 1000));
  if (seconds < 10) return "gerade eben";
  if (seconds < 60) return `vor ${seconds} Sek.`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `vor ${minutes} Min.`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `vor ${hours} Std.`;
  const days = Math.round(hours / 24);
  return `vor ${days} Tg.`;
}
