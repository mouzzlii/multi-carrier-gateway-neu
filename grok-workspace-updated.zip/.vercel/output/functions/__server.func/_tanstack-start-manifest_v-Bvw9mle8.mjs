//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bvw9mle8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index--GB4q2Ud.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index--GB4q2Ud.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D7PyiFeg.js"]
	}
} });
//#endregion
export { tsrStartManifest };
