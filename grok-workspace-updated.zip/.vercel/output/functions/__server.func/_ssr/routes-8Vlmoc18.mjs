import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ScanLine, c as Flashlight, i as Share2, l as ExternalLink, o as Keyboard, r as Trash2, s as History, t as X, u as Copy } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-8Vlmoc18.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var enc = encodeURIComponent;
var CARRIERS = [
	{
		id: "deutsche_post",
		name: "Deutsche Post",
		short: "Post",
		trackingUrl: (code) => `https://www.deutschepost.de/de/s/sendungsverfolgung.html?piececode=${enc(code)}`
	},
	{
		id: "dhl_paket",
		name: "DHL Paket",
		short: "DHL",
		trackingUrl: (code) => `https://www.dhl.de/de/privatkunden/pakete-empfangen/verfolgen.html?piececode=${enc(code)}`
	},
	{
		id: "dhl_express",
		name: "DHL Express",
		short: "DHL Exp",
		trackingUrl: (code) => `https://www.dhl.com/de-de/home/tracking/tracking-express.html?submit=1&tracking-id=${enc(code)}`
	},
	{
		id: "dpd",
		name: "DPD",
		short: "DPD",
		trackingUrl: (code) => `https://tracking.dpd.de/status/de_DE/parcel/${enc(code)}`
	},
	{
		id: "gls",
		name: "GLS",
		short: "GLS",
		trackingUrl: (code) => `https://gls-group.com/DE/de/paketverfolgung?match=${enc(code)}`
	},
	{
		id: "hermes",
		name: "Hermes",
		short: "Hermes",
		trackingUrl: (code) => `https://www.myhermes.de/empfangen/sendungsverfolgung/sendungsinformation/#${enc(code)}`
	},
	{
		id: "ups",
		name: "UPS",
		short: "UPS",
		trackingUrl: (code) => `https://www.ups.com/track?loc=de_DE&tracknum=${enc(code)}`
	},
	{
		id: "fedex",
		name: "FedEx",
		short: "FedEx",
		trackingUrl: (code) => `https://www.fedex.com/fedextrack/?trknbr=${enc(code)}&locale=de_DE`
	},
	{
		id: "post_at",
		name: "Österreichische Post",
		short: "Post AT",
		trackingUrl: (code) => `https://www.post.at/s/sendungsdetails?snr=${enc(code)}`
	}
];
function carrierById(id) {
	return CARRIERS.find((carrier) => carrier.id === id) ?? CARRIERS[1];
}
var SAMPLE_CODES = [
	{
		label: "UPS",
		code: "1Z999AA10123456784"
	},
	{
		label: "DHL Express",
		code: "1234567890"
	},
	{
		label: "DHL Paket",
		code: "00340434161234567890"
	},
	{
		label: "Deutsche Post",
		code: "RR123456789DE"
	},
	{
		label: "DPD",
		code: "01501234567890"
	},
	{
		label: "GLS",
		code: "12345678901"
	},
	{
		label: "Hermes",
		code: "H12345678901234"
	},
	{
		label: "FedEx",
		code: "96123456789012345678"
	},
	{
		label: "Post AT",
		code: "EE123456789AT"
	}
];
var QUERY_KEYS = /* @__PURE__ */ new Set([
	"piececode",
	"tracking-id",
	"trackingid",
	"tracknum",
	"trknbr",
	"match",
	"snr",
	"idc",
	"code",
	"trackingnumber"
]);
function confidenceLabel(score) {
	if (score >= 85) return "Sicher erkannt";
	if (score >= 60) return "Wahrscheinlich";
	return "Bitte prüfen";
}
function normalizeCode(raw) {
	return raw.trim().replace(/^\][A-Za-z]\d/, "").replace(/[\s-]+/g, "").toUpperCase();
}
function extractCode(raw) {
	const trimmed = raw.trim();
	if (/^https?:\/\//i.test(trimmed)) try {
		const url = new URL(trimmed);
		for (const [key, value] of url.searchParams) if (QUERY_KEYS.has(key.toLowerCase()) && value.trim().length >= 4) return normalizeCode(value);
		if (url.hash.length > 4) return normalizeCode(url.hash.slice(1));
		const last = url.pathname.split("/").filter(Boolean).pop();
		if (last && last.length >= 8 && /\d/.test(last) && !last.includes(".")) return normalizeCode(last);
	} catch {}
	return normalizeCode(trimmed);
}
/**
* Best-effort format scoring. Overlapping numeric lengths stay correctable
* in the UI. Keep in sync with the Android CarrierDetector.
*/
function detectCarrier(raw) {
	const code = extractCode(raw);
	const scores = [];
	const put = (carrierId, score, reason) => {
		const index = scores.findIndex((item) => item.carrierId === carrierId);
		if (index >= 0) {
			if (score > scores[index].score) scores[index] = {
				carrierId,
				score,
				reason
			};
			return;
		}
		scores.push({
			carrierId,
			score,
			reason
		});
	};
	if (/^1Z[0-9A-Z]{16}$/.test(code)) put("ups", 100, "UPS-Format 1Z");
	if (/^T\d{10}$/.test(code)) put("ups", 86, "UPS-InfoNotice");
	const s10 = /^([A-Z]{2})(\d{9})([A-Z]{2})$/.exec(code);
	if (s10) {
		const prefix = s10[1];
		const country = s10[3];
		if (country === "AT") put("post_at", 98, "S10 mit Länderkennzeichen AT");
		else if (country === "DE") {
			if (/^[RCELUVA]/.test(prefix)) put("deutsche_post", 94, "S10-Einschreiben Deutschland");
			else put("deutsche_post", 80, "S10 mit Länderkennzeichen DE");
			put("dhl_paket", 55, "S10 mit Länderkennzeichen DE");
		} else {
			put("deutsche_post", 52, "Internationales S10");
			put("dhl_express", 48, "Internationales S10");
		}
	}
	if (/^(JJD|JVGL)/.test(code) || /^0034043\d+/.test(code)) put("dhl_paket", 97, "DHL-Paketkennung");
	if (/^JD\d{10,}$/.test(code)) put("dhl_express", 90, "DHL-Express-Kennung JD");
	if (/^0034\d{10,}$/.test(code)) put("dhl_paket", 92, "DHL-Präfix 0034");
	if (/^H\d{12,16}$/.test(code)) put("hermes", 90, "Hermes-Präfix H");
	if (/^DT\d{12}$/.test(code)) put("fedex", 92, "FedEx Door Tag");
	if (/^\d+$/.test(code)) {
		const length = code.length;
		if (length === 10) put("dhl_express", 88, "10-stellige Express-Waybill");
		if (length === 11) put("gls", 84, "11-stellige GLS-Nummer");
		if (length === 12) {
			if (code.startsWith("00")) put("dhl_paket", 86, "12-stellig mit DHL-Präfix");
			else {
				put("fedex", 70, "12-stellige FedEx-Nummer");
				put("dhl_paket", 62, "12-stellige DHL-Nummer");
				put("gls", 48, "12-stellige GLS-Nummer");
			}
		}
		if (length === 13) put("gls", 60, "13-stellige GLS-Nummer");
		if (length === 14) {
			if (/^(01|05|06|09)/.test(code)) put("dpd", 86, "14-stellig mit DPD-Präfix");
			else put("dpd", 72, "14-stellige DPD-Nummer");
			put("hermes", 68, "14-stellige Hermes-Nummer");
		}
		if (length === 15) put("fedex", 82, "15-stellige FedEx-Nummer");
		if (length === 16) {
			put("hermes", 74, "16-stellige Hermes-Nummer");
			put("dpd", 50, "16-stellige DPD-Nummer");
		}
		if (length === 18) put("ups", 44, "18-stellige UPS-Nummer");
		if (length >= 20 && length <= 22) {
			if (code.startsWith("0034")) put("dhl_paket", 93, "DHL-Leitcode");
			else if (code.startsWith("96")) put("fedex", 88, "FedEx-Nummer 96…");
			else {
				put("dhl_paket", 64, "Lange numerische Sendungsnummer");
				put("fedex", 58, "Lange FedEx-Nummer");
			}
		}
		if (length === 8) put("gls", 40, "8-stellige GLS-Referenz");
		if (length === 9) put("ups", 40, "9-stellige UPS-Referenz");
	}
	if (scores.length === 0) put("dhl_paket", 20, "Kein eindeutiges Format");
	scores.sort((a, b) => b.score - a.score);
	return {
		code,
		matches: scores
	};
}
var STORAGE_KEY = "mcg.history.v1";
function isCarrierId(value) {
	return typeof value === "string" && CARRIERS.some((carrier) => carrier.id === value);
}
function loadHistory() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.flatMap((item) => {
			if (!item || typeof item !== "object") return [];
			const row = item;
			if (typeof row.id !== "string" || typeof row.code !== "string") return [];
			if (!isCarrierId(row.carrierId) || !isCarrierId(row.detectedCarrierId)) return [];
			if (typeof row.at !== "number" || typeof row.confidence !== "number") return [];
			return [{
				id: row.id,
				code: row.code,
				carrierId: row.carrierId,
				detectedCarrierId: row.detectedCarrierId,
				confidence: row.confidence,
				reason: typeof row.reason === "string" ? row.reason : "",
				at: row.at,
				source: row.source === "manual" ? "manual" : "camera",
				corrected: Boolean(row.corrected)
			}];
		});
	} catch {
		return [];
	}
}
function saveHistory(items) {
	localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, 100)));
}
function formatWhen(at, now = Date.now()) {
	const seconds = Math.max(0, Math.round((now - at) / 1e3));
	if (seconds < 10) return "gerade eben";
	if (seconds < 60) return `vor ${seconds} Sek.`;
	const minutes = Math.round(seconds / 60);
	if (minutes < 60) return `vor ${minutes} Min.`;
	const hours = Math.round(minutes / 60);
	if (hours < 24) return `vor ${hours} Std.`;
	return `vor ${Math.round(hours / 24)} Tg.`;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function useBarcodeScanner(onCode, generation) {
	const videoRef = (0, import_react.useRef)(null);
	const onCodeRef = (0, import_react.useRef)(onCode);
	onCodeRef.current = onCode;
	const streamRef = (0, import_react.useRef)(null);
	const [status, setStatus] = (0, import_react.useState)("starting");
	const [torchOn, setTorchOn] = (0, import_react.useState)(false);
	const [torchSupported, setTorchSupported] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) {
			setStatus("error");
			return;
		}
		if (!navigator.mediaDevices?.getUserMedia) {
			setStatus("missing");
			return;
		}
		let stopped = false;
		let controls = null;
		setStatus("starting");
		setTorchOn(false);
		setTorchSupported(false);
		const start = async () => {
			try {
				const { BrowserMultiFormatReader } = await import("../_libs/@zxing/browser+[...].mjs").then((n) => n.t);
				if (stopped) return;
				const nextControls = await new BrowserMultiFormatReader(void 0, { delayBetweenScanAttempts: 280 }).decodeFromConstraints({
					video: { facingMode: { ideal: "environment" } },
					audio: false
				}, video, (result) => {
					if (!result) return;
					try {
						onCodeRef.current(result.getText());
					} catch {}
				});
				if (stopped) {
					nextControls.stop();
					return;
				}
				controls = nextControls;
				const stream = video.srcObject instanceof MediaStream ? video.srcObject : null;
				streamRef.current = stream;
				const caps = (stream?.getVideoTracks()[0])?.getCapabilities?.();
				setTorchSupported(Boolean(caps?.torch));
				setStatus("live");
			} catch (error) {
				if (stopped) return;
				const name = error instanceof DOMException ? error.name : "";
				if (name === "NotAllowedError" || name === "SecurityError") setStatus("denied");
				else if (name === "NotFoundError" || name === "OverconstrainedError") setStatus("missing");
				else setStatus("error");
			}
		};
		start();
		return () => {
			stopped = true;
			controls?.stop();
			streamRef.current?.getTracks().forEach((track) => track.stop());
			streamRef.current = null;
			if (video.srcObject instanceof MediaStream) {
				video.srcObject.getTracks().forEach((track) => track.stop());
				video.srcObject = null;
			}
		};
	}, [generation]);
	async function toggleTorch() {
		const track = streamRef.current?.getVideoTracks()[0];
		if (!track) return false;
		const next = !torchOn;
		try {
			await track.applyConstraints({ advanced: [{ torch: next }] });
			setTorchOn(next);
			return true;
		} catch {
			setTorchSupported(false);
			setTorchOn(false);
			return false;
		}
	}
	return {
		videoRef,
		status,
		torchOn,
		torchSupported,
		toggleTorch
	};
}
function ScannerApp() {
	const [history, setHistory] = (0, import_react.useState)([]);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [activeCode, setActiveCode] = (0, import_react.useState)(null);
	const [panel, setPanel] = (0, import_react.useState)("scan");
	const [generation, setGeneration] = (0, import_react.useState)(0);
	const panelRef = (0, import_react.useRef)(panel);
	panelRef.current = panel;
	const commitRef = (0, import_react.useRef)(() => {});
	const lastCamera = (0, import_react.useRef)({
		code: "",
		at: 0
	});
	(0, import_react.useEffect)(() => {
		setHistory(loadHistory());
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		saveHistory(history);
	}, [history, hydrated]);
	const commit = (raw, source) => {
		const detection = detectCarrier(raw);
		if (detection.code.length < 4) {
			if (source === "manual") toast.error("Nummer zu kurz");
			return;
		}
		const best = detection.matches[0];
		const now = Date.now();
		setHistory((prev) => {
			const existing = prev.find((item) => item.code === detection.code);
			return [existing ? {
				...existing,
				at: now,
				source,
				confidence: best.score,
				reason: best.reason,
				detectedCarrierId: best.carrierId,
				carrierId: existing.corrected ? existing.carrierId : best.carrierId
			} : {
				id: crypto.randomUUID(),
				code: detection.code,
				carrierId: best.carrierId,
				detectedCarrierId: best.carrierId,
				confidence: best.score,
				reason: best.reason,
				at: now,
				source,
				corrected: false
			}, ...prev.filter((item) => item.code !== detection.code)].slice(0, 100);
		});
		setActiveCode(detection.code);
		setPanel("scan");
	};
	commitRef.current = commit;
	const scanner = useBarcodeScanner((text) => {
		if (panelRef.current !== "scan") return;
		const detected = detectCarrier(text);
		const now = Date.now();
		if (detected.code === lastCamera.current.code && now - lastCamera.current.at < 4e3) return;
		lastCamera.current = {
			code: detected.code,
			at: now
		};
		commitRef.current(text, "camera");
	}, generation);
	const active = history.find((item) => item.code === activeCode) ?? null;
	async function copyText(value, message) {
		try {
			await navigator.clipboard.writeText(value);
			toast.success(message);
		} catch {
			toast.error("Kopieren nicht möglich");
		}
	}
	async function shareScan(scan) {
		const carrier = carrierById(scan.carrierId);
		const url = carrier.trackingUrl(scan.code);
		const text = `${carrier.name} ${scan.code}`;
		if (navigator.share) try {
			await navigator.share({
				title: carrier.name,
				text,
				url
			});
			return;
		} catch (error) {
			if (error instanceof DOMException && error.name === "AbortError") return;
		}
		await copyText(`${text}\n${url}`, "Link kopiert");
	}
	function setCarrier(code, carrierId) {
		setHistory((prev) => prev.map((item) => item.code === code ? {
			...item,
			carrierId,
			corrected: carrierId !== item.detectedCarrierId
		} : item));
	}
	function remove(code) {
		setHistory((prev) => prev.filter((item) => item.code !== code));
		setActiveCode((current) => current === code ? null : current);
	}
	async function onTorch() {
		if (scanner.status !== "live") {
			toast.error("Kamera ist nicht aktiv");
			return;
		}
		if (!scanner.torchSupported && !scanner.torchOn) {
			toast.error("Taschenlampe an diesem Gerät nicht verfügbar");
			return;
		}
		if (!await scanner.toggleTorch()) toast.error("Taschenlampe an diesem Gerät nicht verfügbar");
	}
	const cameraMessage = scanner.status === "starting" ? "Kamera wird gestartet…" : scanner.status === "denied" ? "Kein Kamerazugriff. Erlaube die Kamera oder gib die Nummer ein." : scanner.status === "missing" ? "Keine Kamera gefunden. Die Nummer kannst du eintippen." : scanner.status === "error" ? "Kamera konnte nicht gestartet werden." : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg lg:grid lg:grid-cols-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { style: {
					background: "var(--color-surface)",
					color: "var(--color-fg)",
					border: "1px solid var(--color-line)"
				} }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative h-dvh overflow-hidden lg:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "stage-grid absolute inset-0",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: scanner.videoRef,
						className: cn("absolute inset-0 h-full w-full object-cover", scanner.status !== "live" && "opacity-0"),
						muted: true,
						autoPlay: true,
						playsInline: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex h-full min-h-0 flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "flex items-center gap-3 bg-bg px-4 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-12 items-center justify-center rounded-2xl border border-line bg-surface text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, {
											className: "size-6",
											"aria-hidden": "true"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "truncate text-lg font-semibold leading-tight",
											children: "Multi-Carrier Gateway"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: "Scan · Erkennen · Tracking"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
										label: scanner.torchOn ? "Taschenlampe aus" : "Taschenlampe an",
										pressed: scanner.torchOn,
										onClick: () => void onTorch(),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flashlight, { className: "size-5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
										label: "Nummer eingeben",
										onClick: () => setPanel("manual"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "size-5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
										label: "Verlauf",
										className: "lg:hidden",
										onClick: () => setPanel("history"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-5" })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-h-0 flex-1 flex-col items-center justify-center px-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewfinder, { live: scanner.status === "live" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 max-w-sm text-center text-sm text-muted",
										role: "status",
										children: cameraMessage ?? "Halte den Barcode in den Rahmen. Die Kamera bleibt offen."
									}),
									scanner.status !== "live" && scanner.status !== "starting" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4 flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-12 rounded-full border border-line bg-surface px-4 text-sm font-medium",
											onClick: () => setGeneration((value) => value + 1),
											children: "Erneut versuchen"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "h-12 rounded-full bg-primary px-4 text-sm font-semibold text-primary-ink",
											onClick: () => setPanel("manual"),
											children: "Nummer eingeben"
										})]
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "safe-bottom bg-bg px-4 pt-2",
								children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultCard, {
									scan: active,
									onCarrier: (carrierId) => setCarrier(active.code, carrierId),
									onClose: () => setActiveCode(null),
									onCopy: () => void copyText(active.code, "Nummer kopiert"),
									onShare: () => void shareScan(active)
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "pb-4 text-center text-sm text-muted",
									children: history[0] ? `Zuletzt ${carrierById(history[0].carrierId).short} · ${history[0].code}` : "Noch keine Sendung in dieser Sitzung."
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "sr-only",
						"aria-live": "polite",
						children: active ? `${active.code}, ${carrierById(active.carrierId).name}` : ""
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden h-dvh overflow-y-auto border-l border-line bg-surface lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryPanel, {
					history,
					activeCode,
					onSelect: (code) => {
						setActiveCode(code);
						setPanel("scan");
					},
					onRemove: remove,
					onClear: () => {
						setHistory([]);
						setActiveCode(null);
					}
				})
			}),
			panel === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-30 flex flex-col bg-bg lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryPanel, {
					history,
					activeCode,
					onClose: () => setPanel("scan"),
					onSelect: (code) => {
						setActiveCode(code);
						setPanel("scan");
					},
					onRemove: remove,
					onClear: () => {
						setHistory([]);
						setActiveCode(null);
					}
				})
			}) : null,
			panel === "manual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualDialog, {
				onClose: () => setPanel("scan"),
				onSubmit: (value) => commit(value, "manual")
			}) : null
		]
	});
}
function IconButton({ label, pressed, className, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		"aria-pressed": pressed,
		onClick,
		className: cn("inline-flex size-12 shrink-0 items-center justify-center rounded-full border border-line bg-surface text-fg transition-colors duration-200 hover:bg-surface-2", pressed && "border-primary bg-primary text-primary-ink", className),
		children
	});
}
function Viewfinder({ live }) {
	const corner = "absolute size-8 border-primary";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative size-64",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(corner, "top-0 left-0 border-t-4 border-l-4") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(corner, "top-0 right-0 border-t-4 border-r-4") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(corner, "bottom-0 left-0 border-b-4 border-l-4") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn(corner, "right-0 bottom-0 border-r-4 border-b-4") }),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mcg-sweep absolute top-1/2 right-6 left-6 h-0.5 bg-primary" }) : null
		]
	});
}
function ResultCard({ scan, onCarrier, onClose, onCopy, onShare }) {
	const carrier = carrierById(scan.carrierId);
	const detected = carrierById(scan.detectedCarrierId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "result-card mb-4 rounded-3xl border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-primary uppercase",
					children: confidenceLabel(scan.confidence)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-xl font-semibold",
					children: carrier.name
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Ergebnis einklappen",
					onClick: onClose,
					className: "inline-flex size-12 items-center justify-center rounded-full border border-line text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-mono text-lg break-all",
				children: scan.code
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [scan.corrected ? `Manuell gewählt · erkannt als ${detected.name}. ` : "", scan.reason]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-2 overflow-x-auto pb-1",
				children: CARRIERS.map((item) => {
					const selected = item.id === scan.carrierId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": selected,
						onClick: () => onCarrier(item.id),
						className: cn("h-12 shrink-0 rounded-full border px-3 text-sm font-medium", selected ? "border-primary bg-primary text-primary-ink" : "border-line bg-surface-2 text-fg"),
						children: item.short
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: carrier.trackingUrl(scan.code),
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex h-12 items-center justify-center gap-2 rounded-full bg-primary font-semibold text-primary-ink",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
						className: "size-5",
						"aria-hidden": "true"
					}), "Tracking öffnen"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onCopy,
						className: "inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-line bg-surface-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
							className: "size-5",
							"aria-hidden": "true"
						}), "Kopieren"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onShare,
						className: "inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full border border-line bg-surface-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {
							className: "size-5",
							"aria-hidden": "true"
						}), "Teilen"]
					})]
				})]
			})
		]
	});
}
function HistoryPanel({ history, activeCode, onSelect, onRemove, onClear, onClose }) {
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 border-b border-line px-4 py-3",
			children: [
				onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Zurück zum Scan",
					onClick: onClose,
					className: "inline-flex size-12 items-center justify-center rounded-full border border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Verlauf"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Nur auf diesem Gerät"
					})]
				}),
				history.length > 0 && !confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setConfirm(true),
					className: "h-12 rounded-full px-3 text-sm text-muted",
					children: "Alle löschen"
				}) : null,
				confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						onClear();
						setConfirm(false);
					},
					className: "h-12 rounded-full bg-primary px-3 text-sm font-semibold text-primary-ink",
					children: "Wirklich löschen"
				}) : null
			]
		}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col items-center justify-center px-6 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, {
				className: "size-8 text-muted",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Noch keine Sendungen. Scanne einen Code oder gib eine Nummer ein."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "min-h-0 flex-1 overflow-y-auto",
			children: history.map((scan) => {
				const carrier = carrierById(scan.carrierId);
				const selected = scan.code === activeCode;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex items-center gap-2 px-3 py-2", selected && "bg-surface-2"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onSelect(scan.code),
								className: "min-w-0 flex-1 py-2 text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-semibold",
										children: carrier.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block truncate font-mono text-sm",
										children: scan.code
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-xs text-muted",
										children: formatWhen(scan.at)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: carrier.trackingUrl(scan.code),
								target: "_blank",
								rel: "noreferrer",
								"aria-label": `Tracking für ${scan.code} öffnen`,
								className: "inline-flex size-12 items-center justify-center rounded-full border border-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `${scan.code} löschen`,
								onClick: () => onRemove(scan.code),
								className: "inline-flex size-12 items-center justify-center rounded-full border border-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-5" })
							})
						]
					})
				}, scan.id);
			})
		})]
	});
}
function ManualDialog({ onClose, onSubmit }) {
	const [draft, setDraft] = (0, import_react.useState)("");
	const detection = draft.trim().length >= 4 ? detectCarrier(draft) : null;
	const best = detection?.matches[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/80 p-4 lg:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "safe-bottom w-full max-w-md rounded-3xl border border-line bg-surface p-4",
			onSubmit: (event) => {
				event.preventDefault();
				onSubmit(draft);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Nummer eingeben"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Schließen",
						onClick: onClose,
						className: "inline-flex size-12 items-center justify-center rounded-full border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "mt-4 block text-sm text-muted",
					htmlFor: "tracking-code",
					children: "Sendungsnummer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "tracking-code",
					value: draft,
					onChange: (event) => setDraft(event.target.value),
					autoFocus: true,
					autoCapitalize: "characters",
					autoCorrect: "off",
					spellCheck: false,
					placeholder: "z. B. 00340434161234567890",
					className: "mt-2 h-12 w-full rounded-2xl border border-line bg-bg px-3 font-mono text-fg placeholder:text-muted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: best ? `${confidenceLabel(best.score)} · ${carrierById(best.carrierId).name}` : "Mindestens 4 Zeichen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: !detection,
					className: "mt-3 inline-flex h-12 w-full items-center justify-center rounded-full bg-primary font-semibold text-primary-ink disabled:opacity-40",
					children: "Übernehmen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-sm text-muted",
					children: "Testnummern, fiktiv"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2",
					children: SAMPLE_CODES.map((sample) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onSubmit(sample.code),
						className: "h-12 rounded-full border border-line bg-surface-2 px-3 text-sm",
						children: sample.label
					}, sample.code))
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScannerApp, {});
}
//#endregion
export { Home as component };
