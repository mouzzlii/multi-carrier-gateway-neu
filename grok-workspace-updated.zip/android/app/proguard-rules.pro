# Debug builds do not minify. Kept so release builds can turn R8 on later.
-keep class com.google.mlkit.** { *; }
