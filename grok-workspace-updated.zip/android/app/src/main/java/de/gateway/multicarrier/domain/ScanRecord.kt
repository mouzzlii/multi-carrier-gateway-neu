package de.gateway.multicarrier.domain

data class ScanRecord(
    val id: String,
    val code: String,
    val carrierId: String,
    val detectedCarrierId: String,
    val confidence: Int,
    val reason: String,
    val at: Long,
    val source: String,
    val corrected: Boolean,
)
