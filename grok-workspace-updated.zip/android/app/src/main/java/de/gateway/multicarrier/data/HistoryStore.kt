package de.gateway.multicarrier.data

import android.content.Context
import de.gateway.multicarrier.domain.Carrier
import de.gateway.multicarrier.domain.ScanRecord
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(): List<ScanRecord> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val carrierId = item.getString("carrierId")
                    val detected = item.getString("detectedCarrierId")
                    if (Carrier.entries.none { it.id == carrierId }) continue
                    if (Carrier.entries.none { it.id == detected }) continue
                    add(
                        ScanRecord(
                            id = item.getString("id"),
                            code = item.getString("code"),
                            carrierId = carrierId,
                            detectedCarrierId = detected,
                            confidence = item.getInt("confidence"),
                            reason = item.optString("reason"),
                            at = item.getLong("at"),
                            source = item.optString("source", "camera"),
                            corrected = item.optBoolean("corrected", false),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(items: List<ScanRecord>) {
        val array = JSONArray()
        items.take(MAX_ITEMS).forEach { record ->
            array.put(
                JSONObject()
                    .put("id", record.id)
                    .put("code", record.code)
                    .put("carrierId", record.carrierId)
                    .put("detectedCarrierId", record.detectedCarrierId)
                    .put("confidence", record.confidence)
                    .put("reason", record.reason)
                    .put("at", record.at)
                    .put("source", record.source)
                    .put("corrected", record.corrected),
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    private companion object {
        const val PREFS = "mcg.history"
        const val KEY = "items"
        const val MAX_ITEMS = 100
    }
}
