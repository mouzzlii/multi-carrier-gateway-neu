package de.gateway.multicarrier.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight

val Ink = Color(0xFF10140F)
val SurfaceInk = Color(0xFF1A2118)
val Surface2 = Color(0xFF242C22)
val Paper = Color(0xFFF3F1E7)
val Muted = Color(0xFFA3AA98)
val Signal = Color(0xFFE7FF3A)
val SignalInk = Color(0xFF1A2108)
val Line = Color(0xFF343F31)

private val Scheme = darkColorScheme(
    primary = Signal,
    onPrimary = SignalInk,
    secondary = Signal,
    onSecondary = SignalInk,
    background = Ink,
    onBackground = Paper,
    surface = SurfaceInk,
    onSurface = Paper,
    surfaceVariant = Surface2,
    onSurfaceVariant = Muted,
    outline = Line,
)

private val Type = Typography().let { base ->
    base.copy(
        headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    )
}

@Composable
fun MultiCarrierTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Scheme,
        typography = Type,
        content = content,
    )
}
