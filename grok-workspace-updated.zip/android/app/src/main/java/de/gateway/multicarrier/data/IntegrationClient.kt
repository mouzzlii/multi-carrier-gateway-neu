package de.gateway.multicarrier.data

import de.gateway.multicarrier.domain.Carrier
import de.gateway.multicarrier.domain.ScanRecord
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

object IntegrationClient {
    private val executor = Executors.newSingleThreadExecutor()

    fun send(config: IntegrationConfig, record: ScanRecord) {
        val endpoint = config.webhookUrl.trim()
        if (endpoint.isBlank()) return
        executor.execute {
            runCatching {
                val payload = JSONObject()
                    .put("trackingNumber", record.code)
                    .put("carrier", Carrier.fromId(record.carrierId).id)
                    .put("timestamp", record.at)
                    .put("supplierId", if (config.supplierId.isBlank()) JSONObject.NULL else config.supplierId)
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 10_000
                    readTimeout = 10_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                    if (config.apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer ${config.apiKey}")
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
                connection.responseCode
                connection.disconnect()
            }
        }
    }
}
