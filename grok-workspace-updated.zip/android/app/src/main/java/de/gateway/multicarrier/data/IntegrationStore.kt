package de.gateway.multicarrier.data

import android.content.Context

 data class IntegrationConfig(
    val autoTracking: Boolean = true,
    val webhookUrl: String = "",
    val apiKey: String = "",
    val supplierId: String = "",
)

class IntegrationStore(context: Context) {
    private val prefs = context.getSharedPreferences("mcg.integration", Context.MODE_PRIVATE)
    fun load() = IntegrationConfig(
        autoTracking = prefs.getBoolean("autoTracking", true),
        webhookUrl = prefs.getString("webhookUrl", "") ?: "",
        apiKey = prefs.getString("apiKey", "") ?: "",
        supplierId = prefs.getString("supplierId", "") ?: "",
    )
    fun save(config: IntegrationConfig) {
        prefs.edit()
            .putBoolean("autoTracking", config.autoTracking)
            .putString("webhookUrl", config.webhookUrl.trim())
            .putString("apiKey", config.apiKey)
            .putString("supplierId", config.supplierId.trim())
            .apply()
    }
}
