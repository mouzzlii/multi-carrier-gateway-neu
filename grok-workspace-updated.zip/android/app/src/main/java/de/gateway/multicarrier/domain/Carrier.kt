package de.gateway.multicarrier.domain

import java.net.URLEncoder

enum class Carrier(
    val id: String,
    val label: String,
    val shortLabel: String,
) {
    DEUTSCHE_POST("deutsche_post", "Deutsche Post", "Post"),
    DHL_PAKET("dhl_paket", "DHL Paket", "DHL"),
    DHL_EXPRESS("dhl_express", "DHL Express", "DHL Exp"),
    DPD("dpd", "DPD", "DPD"),
    GLS("gls", "GLS", "GLS"),
    HERMES("hermes", "Hermes", "Hermes"),
    UPS("ups", "UPS", "UPS"),
    FEDEX("fedex", "FedEx", "FedEx"),
    POST_AT("post_at", "Österreichische Post", "Post AT"),
    ;

    fun trackingUrl(code: String): String {
        val encoded = URLEncoder.encode(code, "UTF-8")
        return when (this) {
            DEUTSCHE_POST ->
                "https://www.deutschepost.de/de/s/sendungsverfolgung.html?piececode=$encoded"
            DHL_PAKET ->
                "https://www.dhl.de/de/privatkunden/pakete-empfangen/verfolgen.html?piececode=$encoded"
            DHL_EXPRESS ->
                "https://www.dhl.com/de-de/home/tracking/tracking-express.html?submit=1&tracking-id=$encoded"
            DPD -> "https://tracking.dpd.de/status/de_DE/parcel/$encoded"
            GLS -> "https://gls-group.com/DE/de/paketverfolgung?match=$encoded"
            HERMES ->
                "https://www.myhermes.de/empfangen/sendungsverfolgung/sendungsinformation/#$encoded"
            UPS -> "https://www.ups.com/track?loc=de_DE&tracknum=$encoded"
            FEDEX -> "https://www.fedex.com/fedextrack/?trknbr=$encoded&locale=de_DE"
            POST_AT -> "https://www.post.at/s/sendungsdetails?snr=$encoded"
        }
    }

    companion object {
        fun fromId(id: String): Carrier = entries.firstOrNull { it.id == id } ?: DHL_PAKET
    }
}
