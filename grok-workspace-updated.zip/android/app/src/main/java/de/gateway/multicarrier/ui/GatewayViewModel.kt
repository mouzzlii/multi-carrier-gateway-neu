package de.gateway.multicarrier.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import de.gateway.multicarrier.data.HistoryStore
import de.gateway.multicarrier.data.IntegrationConfig
import de.gateway.multicarrier.data.IntegrationClient
import de.gateway.multicarrier.data.IntegrationStore
import android.content.Intent
import android.net.Uri
import de.gateway.multicarrier.domain.CarrierDetector
import de.gateway.multicarrier.domain.ScanRecord
import java.util.UUID

enum class Screen { Scanner, History, Manual, Settings }

data class UiState(
    val history: List<ScanRecord> = emptyList(),
    val activeId: String? = null,
    val screen: Screen = Screen.Scanner,
    val torch: Boolean = false,
    val message: String? = null,
    val messageNonce: Int = 0,
    val integration: IntegrationConfig = IntegrationConfig(),
)

class GatewayViewModel(app: Application) : AndroidViewModel(app) {
    private val store = HistoryStore(app)
    private val integrationStore = IntegrationStore(app)
    private var lastCameraCode = ""
    private var lastCameraAt = 0L

    var state by mutableStateOf(UiState(history = store.load(), integration = integrationStore.load()))
        private set

    fun submit(raw: String, source: String) {
        val detection = CarrierDetector.detect(raw)
        if (detection.code.length < 4) {
            if (source == "manual") notify("Nummer zu kurz")
            return
        }
        val now = System.currentTimeMillis()
        if (source == "camera") {
            if (detection.code == lastCameraCode && now - lastCameraAt < 4_000) return
            lastCameraCode = detection.code
            lastCameraAt = now
        }
        val best = detection.matches.first()
        val runnerUp = detection.matches.getOrNull(1)
        val unambiguous = best.score >= 85 && (runnerUp == null || best.score - runnerUp.score >= 15)
        val existing = state.history.find { it.code == detection.code }
        val record = if (existing != null) {
            existing.copy(
                at = now,
                source = source,
                confidence = best.score,
                reason = best.reason,
                detectedCarrierId = best.carrier.id,
                carrierId = if (existing.corrected) existing.carrierId else best.carrier.id,
            )
        } else {
            ScanRecord(
                id = UUID.randomUUID().toString(),
                code = detection.code,
                carrierId = best.carrier.id,
                detectedCarrierId = best.carrier.id,
                confidence = best.score,
                reason = best.reason,
                at = now,
                source = source,
                corrected = false,
            )
        }
        val next = (listOf(record) + state.history.filter { it.code != detection.code }).take(100)
        store.save(next)
        state = state.copy(history = next, activeId = record.id, screen = Screen.Scanner)
        IntegrationClient.send(state.integration, record)
        if (source == "camera" && state.integration.autoTracking && unambiguous) {
            openTracking(record)
        }
    }


    fun updateIntegration(config: IntegrationConfig) {
        val endpoint = config.webhookUrl.trim()
        if (endpoint.isNotEmpty()) {
            val uri = Uri.parse(endpoint)
            if (uri.scheme !in setOf("https", "http") || uri.host.isNullOrBlank()) {
                notify("Bitte eine gültige HTTP- oder HTTPS-Webhook-URL eingeben")
                return
            }
        }
        integrationStore.save(config)
        state = state.copy(integration = config)
    }

    fun toggleAutoTracking(enabled: Boolean) = updateIntegration(state.integration.copy(autoTracking = enabled))

    private fun openTracking(record: ScanRecord) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(de.gateway.multicarrier.domain.Carrier.fromId(record.carrierId).trackingUrl(record.code)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { getApplication<Application>().startActivity(intent) }
            .onFailure { notify("Kein Browser zum Öffnen des Trackings gefunden") }
    }

    fun processExternalCode(raw: String) = submit(raw, "external")

    fun setCarrier(id: String, carrierId: String) {
        val next = state.history.map { record ->
            if (record.id != id) record
            else record.copy(carrierId = carrierId, corrected = carrierId != record.detectedCarrierId)
        }
        store.save(next)
        state = state.copy(history = next)
    }

    fun remove(id: String) {
        val next = state.history.filterNot { it.id == id }
        store.save(next)
        state = state.copy(
            history = next,
            activeId = if (state.activeId == id) null else state.activeId,
        )
    }

    fun clear() {
        store.save(emptyList())
        state = state.copy(history = emptyList(), activeId = null)
    }

    fun show(screen: Screen) {
        state = state.copy(screen = screen)
    }

    fun dismissActive() {
        state = state.copy(activeId = null)
    }

    fun focus(id: String) {
        state = state.copy(activeId = id, screen = Screen.Scanner)
    }

    fun toggleTorch() {
        state = state.copy(torch = !state.torch)
    }

    fun torchUnsupported() {
        if (!state.torch) return
        state = state.copy(torch = false)
        notify("Taschenlampe nicht verfügbar")
    }

    fun notify(message: String) {
        state = state.copy(message = message, messageNonce = state.messageNonce + 1)
    }

    fun consumeMessage() {
        if (state.message == null) return
        state = state.copy(message = null)
    }

    companion object {
        fun factory(app: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return GatewayViewModel(app) as T
                }
            }
    }
}
