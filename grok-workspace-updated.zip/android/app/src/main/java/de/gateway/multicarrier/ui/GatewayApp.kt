package de.gateway.multicarrier.ui

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import de.gateway.multicarrier.domain.Carrier
import de.gateway.multicarrier.domain.CarrierDetector
import de.gateway.multicarrier.domain.SAMPLE_CODES
import de.gateway.multicarrier.domain.ScanRecord
import de.gateway.multicarrier.domain.confidenceLabel
import de.gateway.multicarrier.ui.scanner.CameraPreview
import de.gateway.multicarrier.ui.theme.Line
import de.gateway.multicarrier.ui.theme.MultiCarrierTheme
import de.gateway.multicarrier.ui.theme.Muted
import de.gateway.multicarrier.ui.theme.Paper
import de.gateway.multicarrier.ui.theme.Signal
import de.gateway.multicarrier.ui.theme.SignalInk
import de.gateway.multicarrier.ui.theme.Surface2
import de.gateway.multicarrier.ui.theme.SurfaceInk
import java.util.Locale

@Composable
fun GatewayRoot(initialCode: String? = null, onExternalResult: ((ScanRecord) -> Unit)? = null) {
    val context = LocalContext.current
    val app = context.applicationContext as android.app.Application
    val vm: GatewayViewModel = viewModel(factory = GatewayViewModel.factory(app))
    val snackbar = remember { SnackbarHostState() }
    val state = vm.state

    LaunchedEffect(initialCode) {
        if (!initialCode.isNullOrBlank()) {
            vm.processExternalCode(initialCode)
            if (onExternalResult != null) vm.state.history.firstOrNull()?.let(onExternalResult)
        }
    }

    LaunchedEffect(state.messageNonce) {
        val message = state.message ?: return@LaunchedEffect
        snackbar.showSnackbar(message)
        vm.consumeMessage()
    }

    BackHandler(enabled = state.screen != Screen.Scanner || state.activeId != null) {
        when {
            state.screen != Screen.Scanner -> vm.show(Screen.Scanner)
            state.activeId != null -> vm.dismissActive()
        }
    }

    MultiCarrierTheme {
        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
        ) {
            when (state.screen) {
                Screen.Scanner -> ScannerScreen(vm)
                Screen.History -> HistoryScreen(vm)
                Screen.Manual -> ManualScreen(vm)
                Screen.Settings -> SettingsScreen(vm)
            }
            SnackbarHost(
                hostState = snackbar,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(top = 8.dp),
            )
        }
    }
}

@Composable
private fun ScannerScreen(vm: GatewayViewModel) {
    val context = LocalContext.current
    val activity = context.findActivity()
    var granted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    var asked by remember { mutableStateOf(false) }
    var cameraFailed by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        asked = true
    }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(Manifest.permission.CAMERA)
    }
    val record = vm.state.history.find { it.id == vm.state.activeId }
    val showSettings = asked && !granted && activity != null &&
        !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.CAMERA)
    val status = when {
        cameraFailed -> "Keine Kamera verfügbar. Du kannst die Nummer eintippen."
        !granted -> "Kein Kamerazugriff. Erlaube die Kamera oder gib die Nummer ein."
        record == null -> "Halte den Barcode in den Rahmen. Die Kamera bleibt offen."
        else -> "Nächster Code ersetzt diese Sendung."
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (granted && !cameraFailed) {
            CameraPreview(
                torch = vm.state.torch,
                onCode = { vm.submit(it, "camera") },
                onTorchUnsupported = vm::torchUnsupported,
                onBindFailed = { cameraFailed = true },
                modifier = Modifier.fillMaxSize(),
            )
        }
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(SurfaceInk.copy(alpha = 0.92f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Multi-Carrier Gateway", style = MaterialTheme.typography.titleMedium)
                    Text("Scan · Erkennen · Tracking", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                RoundIcon(
                    label = if (vm.state.torch) "Taschenlampe aus" else "Taschenlampe an",
                    icon = if (vm.state.torch) Icons.Filled.FlashOn else Icons.Filled.FlashOff,
                    selected = vm.state.torch,
                    onClick = vm::toggleTorch,
                )
                RoundIcon(
                    label = "Nummer eingeben",
                    icon = Icons.Filled.Keyboard,
                    onClick = { vm.show(Screen.Manual) },
                )
                RoundIcon(
                    label = "Verlauf",
                    icon = Icons.Filled.History,
                    onClick = { vm.show(Screen.History) },
                )
                RoundIcon(
                    label = "Einstellungen und Schnittstelle",
                    icon = Icons.Filled.Settings,
                    onClick = { vm.show(Screen.Settings) },
                )
            }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Viewfinder()
                Spacer(Modifier.height(16.dp))
                Text(status, color = Muted, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Text("Auto-Tracking", color = Paper)
                    Spacer(Modifier.width(10.dp))
                    Switch(checked = vm.state.integration.autoTracking, onCheckedChange = vm::toggleAutoTracking)
                }
                if (!granted || cameraFailed) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (showSettings && activity != null) {
                            OutlinedButton(
                                onClick = { context.openAppSettings() },
                                modifier = Modifier.height(48.dp),
                            ) { Text("Einstellungen") }
                        } else if (!granted) {
                            OutlinedButton(
                                onClick = { launcher.launch(Manifest.permission.CAMERA) },
                                modifier = Modifier.height(48.dp),
                            ) { Text("Kamera erlauben") }
                        }
                        Button(
                            onClick = { vm.show(Screen.Manual) },
                            modifier = Modifier.height(48.dp),
                        ) { Text("Nummer eingeben") }
                    }
                }
            }
            if (record != null) {
                ResultCard(record = record, vm = vm)
            } else {
                val last = vm.state.history.firstOrNull()
                Text(
                    text = if (last == null) {
                        "Noch keine Sendung."
                    } else {
                        "Zuletzt ${Carrier.fromId(last.carrierId).shortLabel} · ${last.code}"
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                    color = Muted,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun ResultCard(record: ScanRecord, vm: GatewayViewModel) {
    val context = LocalContext.current
    val carrier = Carrier.fromId(record.carrierId)
    val detected = Carrier.fromId(record.detectedCarrierId)
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(max = 360.dp)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
            .background(SurfaceInk, RoundedCornerShape(24.dp))
            .border(1.dp, Line, RoundedCornerShape(24.dp))
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    confidenceLabel(record.confidence).uppercase(Locale.ROOT),
                    color = Signal,
                    style = MaterialTheme.typography.labelMedium,
                )
                Text(carrier.label, style = MaterialTheme.typography.headlineSmall)
            }
            RoundIcon(label = "Ergebnis einklappen", icon = Icons.Filled.Close, onClick = vm::dismissActive)
        }
        Spacer(Modifier.height(8.dp))
        Text(record.code, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleMedium)
        Text(
            text = buildString {
                if (record.corrected) append("Manuell gewählt · erkannt als ${detected.label}. ")
                append(record.reason)
            },
            color = Muted,
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Carrier.entries.forEach { item ->
                FilterChip(
                    selected = item.id == record.carrierId,
                    onClick = { vm.setCarrier(record.id, item.id) },
                    label = { Text(item.shortLabel) },
                    modifier = Modifier.height(48.dp),
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { openTracking(context, record, vm::notify) },
            modifier = Modifier.fillMaxWidth().height(48.dp),
        ) {
            Icon(Icons.Filled.OpenInNew, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Tracking öffnen")
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    copyCode(context, record.code)
                    vm.notify("Nummer kopiert")
                },
                modifier = Modifier.weight(1f).height(48.dp),
            ) {
                Icon(Icons.Filled.ContentCopy, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Kopieren")
            }
            OutlinedButton(
                onClick = { shareScan(context, record) },
                modifier = Modifier.weight(1f).height(48.dp),
            ) {
                Icon(Icons.Filled.Share, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Teilen")
            }
        }
    }
}

@Composable
private fun HistoryScreen(vm: GatewayViewModel) {
    val context = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RoundIcon(label = "Zurück zum Scan", icon = Icons.Filled.Close, onClick = { vm.show(Screen.Scanner) })
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text("Verlauf", style = MaterialTheme.typography.titleLarge)
                Text("Nur auf diesem Gerät", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            if (vm.state.history.isNotEmpty() && !confirm) {
                TextButton(onClick = { confirm = true }) { Text("Alle löschen") }
            }
            if (confirm) {
                TextButton(onClick = {
                    vm.clear()
                    confirm = false
                }) { Text("Wirklich löschen") }
            }
            if (vm.state.history.isNotEmpty()) {
                TextButton(onClick = { shareHistory(context, vm.state.history, "json", vm.state.integration.supplierId) }) { Text("JSON") }
                TextButton(onClick = { shareHistory(context, vm.state.history, "csv", vm.state.integration.supplierId) }) { Text("CSV") }
            }
        }
        if (vm.state.history.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Noch keine Sendungen. Scanne einen Code oder gib eine Nummer ein.",
                    modifier = Modifier.padding(24.dp),
                    color = Muted,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(vm.state.history, key = { it.id }) { record ->
                    val carrier = Carrier.fromId(record.carrierId)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(SurfaceInk, RoundedCornerShape(16.dp))
                            .border(1.dp, Line, RoundedCornerShape(16.dp))
                            .padding(start = 12.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable { vm.focus(record.id) }
                                .padding(vertical = 8.dp),
                        ) {
                            Text(carrier.label, style = MaterialTheme.typography.titleSmall)
                            Text(record.code, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
                            Text(formatWhen(record.at), color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { openTracking(context, record, vm::notify) }) {
                            Icon(Icons.Filled.OpenInNew, contentDescription = "Tracking öffnen")
                        }
                        IconButton(onClick = { vm.remove(record.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Löschen")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ManualScreen(vm: GatewayViewModel) {
    var draft by remember { mutableStateOf("") }
    val detection = if (draft.trim().length >= 4) CarrierDetector.detect(draft) else null
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(label = "Schließen", icon = Icons.Filled.Close, onClick = { vm.show(Screen.Scanner) })
            Spacer(Modifier.width(8.dp))
            Text("Nummer eingeben", style = MaterialTheme.typography.titleLarge)
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = draft,
            onValueChange = { draft = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Sendungsnummer") },
            textStyle = MaterialTheme.typography.bodyLarge.copy(fontFamily = FontFamily.Monospace),
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.Characters,
                imeAction = ImeAction.Done,
            ),
            keyboardActions = KeyboardActions(onDone = { vm.submit(draft, "manual") }),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = if (detection == null) {
                "Mindestens 4 Zeichen"
            } else {
                val best = detection.matches.first()
                "${confidenceLabel(best.score)} · ${best.carrier.label}"
            },
            color = Muted,
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { vm.submit(draft, "manual") },
            enabled = detection != null,
            modifier = Modifier.fillMaxWidth().height(48.dp),
        ) { Text("Übernehmen") }
        Spacer(Modifier.height(24.dp))
        Text("Testnummern, fiktiv", color = Muted)
        Spacer(Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SAMPLE_CODES.forEach { sample ->
                OutlinedButton(
                    onClick = { vm.submit(sample.code, "manual") },
                    modifier = Modifier.height(48.dp),
                ) { Text(sample.label) }
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: GatewayViewModel) {
    val config = vm.state.integration
    var url by remember(config.webhookUrl) { mutableStateOf(config.webhookUrl) }
    var key by remember(config.apiKey) { mutableStateOf(config.apiKey) }
    var supplier by remember(config.supplierId) { mutableStateOf(config.supplierId) }
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing).verticalScroll(rememberScrollState()).padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIcon(label = "Zurück", icon = Icons.Filled.Close, onClick = { vm.show(Screen.Scanner) })
            Spacer(Modifier.width(8.dp))
            Text("Schnittstellen", style = MaterialTheme.typography.titleLarge)
        }
        Spacer(Modifier.height(16.dp))
        Text("Automatisches Tracking", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Bei eindeutig erkanntem Dienstleister automatisch öffnen", modifier = Modifier.weight(1f), color = Muted)
            Switch(checked = config.autoTracking, onCheckedChange = vm::toggleAutoTracking)
        }
        Spacer(Modifier.height(18.dp))
        Text("Webhook / REST-API", style = MaterialTheme.typography.titleMedium)
        Text("Bei jedem Scan wird im Hintergrund ein JSON-Paket per HTTP-POST gesendet. Verwende eine HTTPS-URL.", color = Muted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Webhook-URL") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = key, onValueChange = { key = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("API-Key (optional)") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = supplier, onValueChange = { supplier = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Supplier-ID (optional)") })
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            vm.updateIntegration(config.copy(webhookUrl = url.trim(), apiKey = key, supplierId = supplier.trim()))
            vm.notify("Schnittstellen-Einstellungen gespeichert")
        }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("Einstellungen speichern") }
        Spacer(Modifier.height(20.dp))
        Text("Datenformat", style = MaterialTheme.typography.titleMedium)
        Text("{ trackingNumber, carrier, timestamp, supplierId } · API-Key wird als Bearer-Token im Authorization-Header übertragen.", color = Muted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { shareHistory(context, vm.state.history, "json", vm.state.integration.supplierId) }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("Alle Sendungen als JSON teilen") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { shareHistory(context, vm.state.history, "csv", vm.state.integration.supplierId) }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("Alle Sendungen als CSV teilen") }
        Spacer(Modifier.height(20.dp))
        Text("Android-Intent: de.gateway.multicarrier.SCAN mit Extra trackingNumber oder Deep-Link trackinggateway://scan?trackingNumber=…", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun RoundIcon(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    selected: Boolean = false,
) {
    IconButton(onClick = onClick, modifier = Modifier.size(48.dp)) {
        Box(
            Modifier
                .size(40.dp)
                .background(if (selected) Signal else Surface2, CircleShape)
                .border(1.dp, if (selected) Signal else Line, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = if (selected) SignalInk else Paper,
                modifier = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun Viewfinder() {
    Canvas(Modifier.size(240.dp)) {
        val stroke = 4.dp.toPx()
        val arm = 28.dp.toPx()
        val w = size.width
        val h = size.height
        val segments = listOf(
            Offset(0f, arm) to Offset(0f, 0f),
            Offset(0f, 0f) to Offset(arm, 0f),
            Offset(w - arm, 0f) to Offset(w, 0f),
            Offset(w, 0f) to Offset(w, arm),
            Offset(0f, h - arm) to Offset(0f, h),
            Offset(0f, h) to Offset(arm, h),
            Offset(w - arm, h) to Offset(w, h),
            Offset(w, h) to Offset(w, h - arm),
        )
        segments.forEach { (start, end) ->
            drawLine(Signal, start, end, strokeWidth = stroke)
        }
    }
}

private fun formatWhen(at: Long, now: Long = System.currentTimeMillis()): String {
    val seconds = ((now - at) / 1000).coerceAtLeast(0)
    return when {
        seconds < 10 -> "gerade eben"
        seconds < 60 -> "vor $seconds Sek."
        seconds < 3_600 -> "vor ${seconds / 60} Min."
        seconds < 86_400 -> "vor ${seconds / 3_600} Std."
        else -> "vor ${seconds / 86_400} Tg."
    }
}

private fun openTracking(context: Context, record: ScanRecord, onError: (String) -> Unit) {
    val url = Carrier.fromId(record.carrierId).trackingUrl(record.code)
    try {
        context.launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (_: ActivityNotFoundException) {
        onError("Kein Browser gefunden")
    }
}

private fun shareScan(context: Context, record: ScanRecord) {
    val carrier = Carrier.fromId(record.carrierId)
    val text = "${carrier.label} ${record.code}\n${carrier.trackingUrl(record.code)}"
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.launch(Intent.createChooser(send, "Sendung teilen"))
}

private fun shareHistory(context: Context, records: List<ScanRecord>, format: String, supplierId: String) {
    val content = if (format == "csv") {
        buildString {
            append("trackingNumber,carrier,timestamp,supplierId\n")
            records.forEach { r ->
                val carrier = Carrier.fromId(r.carrierId).id
                append("\"${r.code.replace("\"", "\"\"")}\",$carrier,${r.at},\"${supplierId.replace("\"", "\"\"")}\"\n")
            }
        }
    } else {
        org.json.JSONArray().apply {
            records.forEach { r -> put(org.json.JSONObject().put("trackingNumber", r.code).put("carrier", Carrier.fromId(r.carrierId).id).put("timestamp", r.at).put("supplierId", if (supplierId.isBlank()) org.json.JSONObject.NULL else supplierId)) }
        }.toString(2)
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = if (format == "csv") "text/csv" else "application/json"
        putExtra(Intent.EXTRA_TEXT, content)
    }
    context.launch(Intent.createChooser(send, "Sendungen als ${format.uppercase(Locale.ROOT)} teilen"))
}

private fun copyCode(context: Context, code: String) {
    val clipboard = context.getSystemService(ClipboardManager::class.java) ?: return
    clipboard.setPrimaryClip(ClipData.newPlainText("Sendungsnummer", code))
}

private fun Context.openAppSettings() {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.fromParts("package", packageName, null)
    }
    launch(intent)
}

private fun Context.launch(intent: Intent) {
    if (this !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
