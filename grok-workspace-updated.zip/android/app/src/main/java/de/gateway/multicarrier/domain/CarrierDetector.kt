package de.gateway.multicarrier.domain

import android.net.Uri
import java.util.Locale

data class CarrierMatch(
    val carrier: Carrier,
    val score: Int,
    val reason: String,
)

data class Detection(
    val code: String,
    val matches: List<CarrierMatch>,
)

data class SampleCode(
    val label: String,
    val code: String,
)

val SAMPLE_CODES = listOf(
    SampleCode("UPS", "1Z999AA10123456784"),
    SampleCode("DHL Express", "1234567890"),
    SampleCode("DHL Paket", "00340434161234567890"),
    SampleCode("Deutsche Post", "RR123456789DE"),
    SampleCode("DPD", "01501234567890"),
    SampleCode("GLS", "12345678901"),
    SampleCode("Hermes", "H12345678901234"),
    SampleCode("FedEx", "96123456789012345678"),
    SampleCode("Post AT", "EE123456789AT"),
)

fun confidenceLabel(score: Int): String = when {
    score >= 85 -> "Sicher erkannt"
    score >= 60 -> "Wahrscheinlich"
    else -> "Bitte prüfen"
}

/**
 * Best-effort format scoring. Keep in sync with src/lib/carriers.ts.
 */
object CarrierDetector {
    private val queryKeys = setOf(
        "piececode",
        "tracking-id",
        "trackingid",
        "tracknum",
        "trknbr",
        "match",
        "snr",
        "idc",
        "code",
        "trackingnumber",
    )

    fun detect(raw: String): Detection {
        val code = extract(raw)
        val scores = mutableListOf<CarrierMatch>()

        fun put(carrier: Carrier, score: Int, reason: String) {
            val index = scores.indexOfFirst { it.carrier == carrier }
            if (index >= 0) {
                if (score > scores[index].score) {
                    scores[index] = CarrierMatch(carrier, score, reason)
                }
            } else {
                scores += CarrierMatch(carrier, score, reason)
            }
        }

        if (Regex("^1Z[0-9A-Z]{16}$").matches(code)) put(Carrier.UPS, 100, "UPS-Format 1Z")
        if (Regex("^T\\d{10}$").matches(code)) put(Carrier.UPS, 86, "UPS-InfoNotice")

        val s10 = Regex("^([A-Z]{2})(\\d{9})([A-Z]{2})$").matchEntire(code)
        if (s10 != null) {
            val prefix = s10.groupValues[1]
            val country = s10.groupValues[3]
            when (country) {
                "AT" -> put(Carrier.POST_AT, 98, "S10 mit Länderkennzeichen AT")
                "DE" -> {
                    if (prefix[0] in "RCELUVA") {
                        put(Carrier.DEUTSCHE_POST, 94, "S10-Einschreiben Deutschland")
                    } else {
                        put(Carrier.DEUTSCHE_POST, 80, "S10 mit Länderkennzeichen DE")
                    }
                    put(Carrier.DHL_PAKET, 55, "S10 mit Länderkennzeichen DE")
                }
                else -> {
                    put(Carrier.DEUTSCHE_POST, 52, "Internationales S10")
                    put(Carrier.DHL_EXPRESS, 48, "Internationales S10")
                }
            }
        }

        if (Regex("^(JJD|JVGL)").containsMatchIn(code) || Regex("^0034043\\d+").containsMatchIn(code)) {
            put(Carrier.DHL_PAKET, 97, "DHL-Paketkennung")
        }
        if (Regex("^JD\\d{10,}$").matches(code)) put(Carrier.DHL_EXPRESS, 90, "DHL-Express-Kennung JD")
        if (Regex("^0034\\d{10,}$").matches(code)) put(Carrier.DHL_PAKET, 92, "DHL-Präfix 0034")
        if (Regex("^H\\d{12,16}$").matches(code)) put(Carrier.HERMES, 90, "Hermes-Präfix H")
        if (Regex("^DT\\d{12}$").matches(code)) put(Carrier.FEDEX, 92, "FedEx Door Tag")

        if (Regex("^\\d+$").matches(code)) {
            when (code.length) {
                8 -> put(Carrier.GLS, 40, "8-stellige GLS-Referenz")
                9 -> put(Carrier.UPS, 40, "9-stellige UPS-Referenz")
                10 -> put(Carrier.DHL_EXPRESS, 88, "10-stellige Express-Waybill")
                11 -> put(Carrier.GLS, 84, "11-stellige GLS-Nummer")
                12 -> {
                    if (code.startsWith("00")) {
                        put(Carrier.DHL_PAKET, 86, "12-stellig mit DHL-Präfix")
                    } else {
                        put(Carrier.FEDEX, 70, "12-stellige FedEx-Nummer")
                        put(Carrier.DHL_PAKET, 62, "12-stellige DHL-Nummer")
                        put(Carrier.GLS, 48, "12-stellige GLS-Nummer")
                    }
                }
                13 -> put(Carrier.GLS, 60, "13-stellige GLS-Nummer")
                14 -> {
                    if (Regex("^(01|05|06|09)").containsMatchIn(code)) {
                        put(Carrier.DPD, 86, "14-stellig mit DPD-Präfix")
                    } else {
                        put(Carrier.DPD, 72, "14-stellige DPD-Nummer")
                    }
                    put(Carrier.HERMES, 68, "14-stellige Hermes-Nummer")
                }
                15 -> put(Carrier.FEDEX, 82, "15-stellige FedEx-Nummer")
                16 -> {
                    put(Carrier.HERMES, 74, "16-stellige Hermes-Nummer")
                    put(Carrier.DPD, 50, "16-stellige DPD-Nummer")
                }
                18 -> put(Carrier.UPS, 44, "18-stellige UPS-Nummer")
            }
            if (code.length in 20..22) {
                when {
                    code.startsWith("0034") -> put(Carrier.DHL_PAKET, 93, "DHL-Leitcode")
                    code.startsWith("96") -> put(Carrier.FEDEX, 88, "FedEx-Nummer 96…")
                    else -> {
                        put(Carrier.DHL_PAKET, 64, "Lange numerische Sendungsnummer")
                        put(Carrier.FEDEX, 58, "Lange FedEx-Nummer")
                    }
                }
            }
        }

        if (scores.isEmpty()) put(Carrier.DHL_PAKET, 20, "Kein eindeutiges Format")
        return Detection(code, scores.sortedByDescending { it.score })
    }

    private fun extract(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            val uri = Uri.parse(trimmed)
            for (name in uri.queryParameterNames) {
                if (name.lowercase(Locale.ROOT) !in queryKeys) continue
                val value = uri.getQueryParameter(name)
                if (!value.isNullOrBlank() && value.trim().length >= 4) return normalize(value)
            }
            val fragment = uri.fragment
            if (!fragment.isNullOrBlank() && fragment.length >= 4) return normalize(fragment)
            val last = uri.lastPathSegment
            if (!last.isNullOrBlank() && last.length >= 8 && last.any { it.isDigit() }) {
                return normalize(last)
            }
        }
        return normalize(trimmed)
    }

    private fun normalize(raw: String): String {
        return raw
            .trim()
            .replace(Regex("^\\][A-Za-z]\\d"), "")
            .replace(Regex("[\\s-]+"), "")
            .uppercase(Locale.ROOT)
    }
}
