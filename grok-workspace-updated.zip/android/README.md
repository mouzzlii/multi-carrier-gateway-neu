# Multi-Carrier Gateway

Android-App (`de.gateway.multicarrier`) zum Scannen von Sendungsnummern. Kamera über CameraX, Barcodes über Google ML Kit (Modell im APK), Oberfläche in Jetpack Compose.

Erkannte Dienste: Deutsche Post, DHL Paket, DHL Express, DPD, GLS, Hermes, UPS, FedEx, Österreichische Post. Die Zuordnung läuft über das Nummernformat und kann vor dem Öffnen des Trackings korrigiert werden.

## Debug-APK

GitHub Actions (ubuntu-latest, JDK 17) baut bei Push auf `main` oder `master`, bei Pull Requests und manuell über **Run workflow**. Das Artefakt heißt `multi-carrier-gateway-debug`.

Liegt nur dieser Ordner im Repository, gilt [`.github/workflows/android-debug.yml`](.github/workflows/android-debug.yml). Liegt er unter `android/` in einem größeren Repo, gilt der Workflow im Repo-Root.

Lokal, mit installiertem Android SDK:

```bash
chmod +x ./gradlew
./gradlew :app:assembleDebug
```

Die APK liegt danach unter `app/build/outputs/apk/debug/`.

## Integrationen (Auto-Tracking, Webhook, Export)

- Der Schalter **Auto-Tracking** auf dem Scanner öffnet nach einem Kamerascan automatisch die Tracking-Seite, wenn die Erkennung sicher ist (Score mindestens 85 und mindestens 15 Punkte Abstand zum nächsten Treffer). Bei unsicherer Erkennung bleibt die manuelle Auswahl sichtbar.
- Unter **Einstellungen** können Webhook-URL, optionaler Bearer-API-Key und Supplier-ID hinterlegt werden. Jeder akzeptierte Scan sendet im Hintergrund `POST` mit `Content-Type: application/json` und den Feldern `trackingNumber`, `carrier`, `timestamp` (Unix-Millisekunden) und `supplierId`. Die App benötigt dafür die Android-Internetberechtigung. Der HTTP-Aufruf hat 10 Sekunden Connect-/Read-Timeout; ein Serverfehler blockiert den Scan nicht.
- Verlauf und Einstellungen bieten CSV-/JSON-Teilen über das Android-Teilen-Menü.
- Externe Apps können `de.gateway.multicarrier.SCAN` mit dem String-Extra `trackingNumber` starten oder `trackinggateway://scan?trackingNumber=...` öffnen. Die App verarbeitet die Nummer und beendet sich bei einem gültigen Scan mit `RESULT_OK`; zurückgegeben werden `trackingNumber`, `carrier` und `trackingUrl`. Bei ungültiger Eingabe bleibt die App zur manuellen Korrektur geöffnet.
- Der API-Key wird lokal in App-Preferences gespeichert. Für produktive Lieferanten-Setups sollte die URL HTTPS verwenden und der Schlüssel regelmäßig rotiert werden.
